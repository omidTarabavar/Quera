import java.util.*;

public class Assignment2 {
    // incomplete
    static Scanner keyboard =new Scanner(System.in);
    public static void main(String[] args) {
        int n = keyboard.nextInt();
        int[] A =new int[n];
        int[] B = new int[n];
        fillArray(A);
        fillArray(B);
        System.out.println(findMatchingSet(A,B));
    }
    static void fillArray(int[] array){
        for(int i = 0 ; i < array.length ; i++){
            array[i] = keyboard.nextInt();
        }
    }
    static int MatchingPairs(int[] A,int[] B){
        ArrayList<int[]> matchinSet = findMatchingSet(A,B);
        return matchinSet.size();
    }
    static boolean findDup(int[] a,int[] b){
        if(a[0] == b[0] || a[1] == b[1]){
            return true;
        }
        return false;
    }

    static ArrayList<int[]> findMatchingSet(int[] A,int[] B){
        ArrayList<int[]> matchingSet = new ArrayList<>();
        for(int i = 0 ; i < A.length;i++){
            for(int j = 0 ; j < B.length;j++){
                if(A[i] == B[j]){
                    int[] pairs ={i,j};
                    matchingSet.add(pairs);
                }
            }
        }
        return matchingSet;
    }

}
